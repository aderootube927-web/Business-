let patients = JSON.parse(localStorage.getItem("opdPatients")) || [];

function saveData(){
  localStorage.setItem("opdPatients", JSON.stringify(patients));
}

function showPage(id){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  refreshAll();
}

function registerPatient(event){
  event.preventDefault();

  const patient = {
    id: "OPD-" + Date.now() + "-" + Math.random().toString(36).slice(2,6),
    firstName: document.getElementById("firstName").value.trim(),
    lastName: document.getElementById("lastName").value.trim(),
    age: document.getElementById("age").value,
    sex: document.getElementById("sex").value,
    phone: document.getElementById("phone").value.trim(),
    address: document.getElementById("address").value.trim(),
    status: "Waiting",
    registeredAt: new Date().toISOString(),
    consultation: null
  };

  patients.push(patient);
  saveData();
  event.target.reset();
  alert("Patient registered successfully.\nID: " + patient.id);
  refreshAll();
}

function isToday(value){
  if(!value) return false;
  const d=new Date(value), t=new Date();
  return d.getFullYear()===t.getFullYear() &&
         d.getMonth()===t.getMonth() &&
         d.getDate()===t.getDate();
}

function updateDashboard(){
  const today=patients.filter(p=>isToday(p.registeredAt));

  document.getElementById("todayPatients").textContent=today.length;
  document.getElementById("newPatients").textContent=today.length;
  document.getElementById("waitingPatients").textContent=
    patients.filter(p=>p.status==="Waiting").length;
  document.getElementById("completedPatients").textContent=
    patients.filter(p=>p.status==="Completed").length;

  document.getElementById("dashboardTable").innerHTML=
    patients.slice(-10).reverse().map(p=>`
      <tr><td>${p.id}</td><td>${p.firstName} ${p.lastName}</td>
      <td>${p.age}</td><td>${p.sex}</td>
      <td><span class="badge">${p.status}</span></td></tr>`).join("");
}

function renderPatients(list=patients){
  document.getElementById("patientsTable").innerHTML=list.map(p=>`
    <tr><td>${p.id}</td><td>${p.firstName} ${p.lastName}</td>
    <td>${p.age}</td><td>${p.sex}</td><td>${p.phone||"-"}</td>
    <td><span class="badge">${p.status}</span></td></tr>`).join("");
}

function searchPatients(){
  const q=document.getElementById("searchPatient").value.toLowerCase();
  renderPatients(patients.filter(p=>
    (p.id+" "+p.firstName+" "+p.lastName+" "+(p.phone||"")).toLowerCase().includes(q)
  ));
}

function renderQueue(){
  const waiting=patients.filter(p=>p.status==="Waiting");
  document.getElementById("queueTable").innerHTML=waiting.map((p,i)=>`
    <tr><td>${i+1}</td><td>${p.firstName} ${p.lastName}</td><td>${p.id}</td>
    <td><span class="badge">${p.status}</span></td>
    <td><button onclick="startConsultation('${p.id}')">Consult</button></td></tr>
  `).join("");
}

function startConsultation(id){
  const p=patients.find(x=>x.id===id);
  if(!p)return;
  p.status="Consultation";
  saveData();
  showPage("consultation");
  populateConsultPatients();
  document.getElementById("consultPatient").value=id;
  refreshAll();
}

function populateConsultPatients(){
  const s=document.getElementById("consultPatient");
  const current=s.value;
  s.innerHTML='<option value="">Select Patient</option>';
  patients.filter(p=>p.status!=="Completed").forEach(p=>{
    s.innerHTML+=`<option value="${p.id}">${p.id} - ${p.firstName} ${p.lastName}</option>`;
  });
  if(patients.some(p=>p.id===current))s.value=current;
}

function saveConsultation(){
  const id=document.getElementById("consultPatient").value;
  if(!id){alert("Please select patient.");return;}
  const p=patients.find(x=>x.id===id);
  if(!p)return;

  p.consultation={
    complaint:document.getElementById("complaint").value,
    bp:document.getElementById("bp").value,
    pulse:document.getElementById("pulse").value,
    temperature:document.getElementById("temperature").value,
    spo2:document.getElementById("spo2").value,
    diagnosis:document.getElementById("diagnosis").value,
    treatment:document.getElementById("treatment").value,
    date:new Date().toISOString()
  };
  p.status="Completed";
  saveData();
  alert("Consultation saved successfully.");

  ["complaint","bp","pulse","temperature","spo2","diagnosis","treatment"]
    .forEach(id=>document.getElementById(id).value="");
  document.getElementById("consultPatient").value="";
  refreshAll();
}

function updateReports(){
  document.getElementById("reportTotal").textContent=patients.length;
  document.getElementById("reportMale").textContent=
    patients.filter(p=>p.sex==="Male").length;
  document.getElementById("reportFemale").textContent=
    patients.filter(p=>p.sex==="Female").length;
}

function refreshAll(){
  renderPatients();
  renderQueue();
  populateConsultPatients();
  updateDashboard();
  updateReports();
}

refreshAll();
