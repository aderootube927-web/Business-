# Bahmni OPD Basic

Basic standalone OPD demo.

Files:
- index.html
- css/style.css
- js/app.js

Run:
Open index.html in a modern browser.

Features:
Dashboard, registration, patient list/search, OPD queue, basic consultation, reports, and localStorage.

This is a demo and is not connected to a Bahmni/OpenMRS backend. Do not use real patient data without appropriate security and clinical-system integration.
