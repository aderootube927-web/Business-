# Bahmni OPD Demo

Standalone HTML/CSS/JavaScript OPD interface based on the supplied code.

## Run
Open `index.html` in a modern browser.

## Important
This is a standalone demo. Patient data is stored in browser localStorage. It is not connected to an OpenMRS/Bahmni backend and should not be used for real patient data without proper authentication, security, database, audit logging, backup, and clinical-system integration.
