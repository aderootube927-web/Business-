let patients=JSON.parse(localStorage.getItem("opdPatients"))||[];

function saveData(){localStorage.setItem("opdPatients",JSON.stringify(patients));}

function showPage(page,element){
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 document.getElementById(page).classList.add("active");
 document.querySelectorAll("aside a").forEach(a=>a.classList.remove("active"));
 element.classList.add("active"); refreshAll();
}

function registerPatient(event){
 event.preventDefault();
 const patient={id:"OPD-"+Date.now().toString().slice(-6),
 firstName:document.getElementById("firstName").value,lastName:document.getElementById("lastName").value,
 age:document.getElementById("age").value,sex:document.getElementById("sex").value,
 phone:document.getElementById("phone").value,address:document.getElementById("address").value,
 status:"Waiting",registeredAt:new Date().toLocaleString(),consultation:null};
 patients.push(patient);saveData();alert("Patient registered successfully.\nPatient ID: "+patient.id);
 event.target.reset();refreshAll();
}

function renderPatients(list=patients){
 const table=document.getElementById("patientsTable");table.innerHTML="";
 list.forEach(p=>{table.innerHTML+=`<tr><td>${p.id}</td><td>${p.firstName} ${p.lastName}</td><td>${p.age}</td><td>${p.sex}</td><td>${p.phone||"-"}</td><td><span class="badge">${p.status}</span></td></tr>`;});
}

function searchPatients(){
 const q=document.getElementById("searchPatient").value.toLowerCase();
 renderPatients(patients.filter(p=>(p.firstName+" "+p.lastName+" "+p.id+" "+p.phone).toLowerCase().includes(q)));
}

function renderQueue(){
 const table=document.getElementById("queueTable");table.innerHTML="";
 patients.filter(p=>p.status==="Waiting").forEach((p,index)=>{table.innerHTML+=`<tr><td>${index+1}</td><td>${p.firstName} ${p.lastName}</td><td>${p.id}</td><td><span class="badge">${p.status}</span></td><td><button onclick="startConsultation('${p.id}')">Consult</button></td></tr>`;});
}

function startConsultation(id){
 const patient=patients.find(p=>p.id===id);if(!patient)return;patient.status="Consultation";saveData();
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById("consultation").classList.add("active");
 populateConsultPatients();document.getElementById("consultPatient").value=id;refreshAll();
}

function populateConsultPatients(){
 const select=document.getElementById("consultPatient");select.innerHTML='<option value="">Select Patient</option>';
 patients.forEach(p=>{select.innerHTML+=`<option value="${p.id}">${p.id} - ${p.firstName} ${p.lastName}</option>`;});
}

function saveConsultation(){
 const id=document.getElementById("consultPatient").value;if(!id){alert("Please select patient.");return;}
 const patient=patients.find(p=>p.id===id);
 patient.consultation={complaint:document.getElementById("complaint").value,bp:document.getElementById("bp").value,
 pulse:document.getElementById("pulse").value,temperature:document.getElementById("temperature").value,
 spo2:document.getElementById("spo2").value,notes:document.getElementById("notes").value,
 diagnosis:document.getElementById("diagnosis").value,treatment:document.getElementById("treatment").value,date:new Date().toLocaleString()};
 patient.status="Completed";saveData();alert("Consultation saved successfully.");
 document.getElementById("complaint").value="";document.getElementById("bp").value="";document.getElementById("pulse").value="";
 document.getElementById("temperature").value="";document.getElementById("spo2").value="";document.getElementById("notes").value="";
 document.getElementById("diagnosis").value="";document.getElementById("treatment").value="";refreshAll();
}

function updateDashboard(){
 document.getElementById("todayPatients").textContent=patients.length;
 document.getElementById("waitingPatients").textContent=patients.filter(p=>p.status==="Waiting").length;
 document.getElementById("completedPatients").textContent=patients.filter(p=>p.status==="Completed").length;
 document.getElementById("newPatients").textContent=patients.filter(p=>p.status==="Waiting").length;
 const table=document.getElementById("dashboardTable");table.innerHTML="";
 patients.slice(-10).reverse().forEach(p=>{table.innerHTML+=`<tr><td>${p.id}</td><td>${p.firstName} ${p.lastName}</td><td>${p.age}</td><td>${p.sex}</td><td><span class="badge">${p.status}</span></td></tr>`;});
}

function updateReports(){
 document.getElementById("reportTotal").textContent=patients.length;
 document.getElementById("reportMale").textContent=patients.filter(p=>p.sex==="Male").length;
 document.getElementById("reportFemale").textContent=patients.filter(p=>p.sex==="Female").length;
}

function refreshAll(){renderPatients();renderQueue();populateConsultPatients();updateDashboard();updateReports();}
refreshAll();
